# C Programming Slot A Assignment 1

All 10 programs are combined in `all_programs.c`. Compile and run the file, then choose a question number from 1 to 10.

Example with GCC:
```bash
gcc all_programs.c -o all_programs
./all_programs
```

On Windows, run `all_programs.exe` after compiling.

Note: Question 6's exact road-selection rule is unclear in the assignment; the program uses car number modulo 3 as an assumption matching the sample.
